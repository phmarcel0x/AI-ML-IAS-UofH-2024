Simply run main.py
Thanks for reading!

Have a lovely day :)